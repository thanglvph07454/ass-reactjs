import React from 'react'
import PropTypes from 'prop-types'

const Dashboard = props => {
    return (
        <div>
            Dashboard page
        </div>
    )
}

Dashboard.propTypes = {

}

export default Dashboard
