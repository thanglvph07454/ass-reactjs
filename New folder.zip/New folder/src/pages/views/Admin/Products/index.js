import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import makeRequest from '../../../../api/axiosHttp';
import React, { useState, useEffect } from 'react';
import Swal from 'sweetalert2'

const ProductsManager = ({onRemove, products }) => {
    

    // const [products, setProducts] = useState([]);

    // useEffect(() => {        
    //     const getProducts = async () => {
    //       try {
    //         let url = 'http://localhost:3004/products';            
    //         const {data} =  await makeRequest(url);
    //         setProducts(data);
        
    //       } catch (error) {
    //         console.log('failed to request API: ', error)
    //       }
    //     }
    //     getProducts();
    // });


    

    const removeHandle = (id) => {

        Swal.fire({
            title: 'Bạn có chắc chắn muốn xóa?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'OK'
          }).then((result) => {
            if (result.value) {
                onRemove(id)
              Swal.fire(
                'Xóa thành công',
              )
            }
          })
        // onRemove(id);
        console.log(id)

    }



    return (
        <div>
            {/* Page Heading */}
            <h1 className="h3 mb-2 text-gray-800">Tables</h1>
            <p className="mb-4">DataTables is a third party plugin that is used to generate the demo table below. For more
          information about DataTables, please visit the <a target="_blank" href="https://datatables.net">official
            DataTables documentation</a>.</p>
            {/* DataTales Example */}
            <div className="card shadow mb-4">
                <div className="card-header py-3">
                    {/* <h6 className="m-0 font-weight-bold text-primary">DataTables Example</h6> */}
                    <Link to = "/admin/products/add" className = "btn btn-success"> Thêm sản phẩm</Link>
                </div>
                <div className="card-body">
                    <div className="table-responsive">
                        <table className="table">
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Image</th>
                                    <th scope="col">Price</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {products.map(({ id, name, image, price }, index) => (
                                    <tr key={index}>
                                        <th scope="row">{id}</th>
                                        <Link to = {`/admin/products/detail/${id}`}><td>{name}</td></Link>
                                        <td><img src={image} alt="" width="50" /></td>
                                        <td>{price}</td>
                                        <td>
                                            <button className="btn btn-danger" onClick={() => removeHandle(id)}>Xóa</button>
                                            
                                     

                                            <Link className='btn btn-primary ml-2' to={`/admin/products/edit/${id}`}>Sửa</Link>
                                        </td>
                                    </tr>
                                ))}

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    )
}

ProductsManager.propTypes = {

}

export default ProductsManager