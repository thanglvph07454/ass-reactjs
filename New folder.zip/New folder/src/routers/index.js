import React, {useState} from 'react'
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Main from '../pages/layouts/Main'
import MainAdmin from '../pages/layouts/MainAdmin'
//Admin
import Dashboard from '../pages/views/Admin/Dashboard'
import ProductsManager from '../pages/views/Admin/Products'

//Views
import About from '../pages/views/Main/About'
import Home from '../pages/views/Main/Home'
import AddProduct from '../pages/views/Admin/AddProduct';
import DetailProduct from '../pages/views/Admin/DetailProduct';
import Shop from '../pages/views/Main/Shop';
import Detail from '../pages/views/Main/Detail';
import EditProduct from '../pages/views/Admin/EditProduct';


const Routers = ({products, onRemove, onAdd, onUpdate }) => {
    const onHandleRemove = (id) => {
        onRemove(id)
    }
    function onHandleAdd(product) {
        onAdd(product)
      }
    function onHandleUpdate(id, product) {
        onUpdate(id, product)
    }
    return (
        <Router>
            <Switch>
                <Route path="/admin/:path?/:path?/:path?" exact>
                    <MainAdmin>
                        <Switch>
                            <Route path='/admin' exact>
                                <Dashboard />
                            </Route>
                            <Route path='/admin/products' exact>
                                <ProductsManager products={products} onRemove={onHandleRemove} />
                            </Route>
                            <Route path='/admin/products/add'>
                                <AddProduct onAdd={onHandleAdd}/>
                            </Route>
                            <Route path='/admin/products/detail/:id'>
                                <DetailProduct products={products} />
                            </Route>
                            <Route path='/admin/products/edit/:id'>
                                <EditProduct products={products} onUpdate={onHandleUpdate}/>
                            </Route>
                        </Switch>
                    </MainAdmin>
                </Route>
                <Route>
                    <Main>
                        <Switch>
                            <Route path="/" exact>
                                <Home />
                            </Route>
                            <Route path="/about">
                                <About />
                            </Route>
                            <Route path="/shop" exact>
                                <Shop products={products}/>
                            </Route>
                            <Route path="/shop/detail/:id">
                                <Detail products={products}/>
                            </Route>
                        </Switch>
                    </Main>
                </Route>
            </Switch>
        </Router>
    )
}

Routers.propTypes = {

}

export default Routers
